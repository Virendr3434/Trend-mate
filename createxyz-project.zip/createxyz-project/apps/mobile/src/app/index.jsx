import { useEffect, useState } from "react";
import { View, Text, Animated } from "react-native";
import { Redirect } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { StatusBar } from "expo-status-bar";
import { useAuth } from "@/utils/auth/useAuth";
import useUser from "@/utils/auth/useUser";

export default function Index() {
  const { isReady, auth } = useAuth();
  const { data: user, loading: userLoading } = useUser();
  const [fadeAnim] = useState(new Animated.Value(0));
  const [scaleAnim] = useState(new Animated.Value(0.8));

  useEffect(() => {
    if (isReady) {
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          tension: 50,
          friction: 7,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [isReady]);

  if (!isReady || userLoading) {
    return (
      <LinearGradient
        colors={["#1E3A8A", "#EA580C"]}
        style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
      >
        <StatusBar style="light" />
        <Animated.View
          style={{
            opacity: fadeAnim,
            transform: [{ scale: scaleAnim }],
            alignItems: "center",
          }}
        >
          {/* 3D Coin Logo */}
          <View
            style={{
              width: 120,
              height: 120,
              borderRadius: 60,
              backgroundColor: "#FFD700",
              justifyContent: "center",
              alignItems: "center",
              marginBottom: 24,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.3,
              shadowRadius: 16,
              elevation: 8,
            }}
          >
            <Text
              style={{ fontSize: 48, fontWeight: "bold", color: "#1E3A8A" }}
            >
              D
            </Text>
          </View>

          <Text
            style={{
              fontSize: 32,
              fontWeight: "bold",
              color: "#FFFFFF",
              marginBottom: 8,
              textShadowColor: "rgba(0,0,0,0.3)",
              textShadowOffset: { width: 0, height: 2 },
              textShadowRadius: 4,
            }}
          >
            Dropzy
          </Text>

          <Text
            style={{
              fontSize: 16,
              color: "rgba(255,255,255,0.8)",
              textAlign: "center",
              paddingHorizontal: 40,
            }}
          >
            Refer & Earn with 3D Rewards
          </Text>
        </Animated.View>
      </LinearGradient>
    );
  }

  // If user is authenticated but no profile exists, go to onboarding
  if (auth && !user) {
    return <Redirect href="/onboarding" />;
  }

  // If user has profile, go to main app
  if (auth && user) {
    return <Redirect href="/(tabs)" />;
  }

  // If not authenticated, stay on this screen (AuthModal will show)
  return (
    <LinearGradient
      colors={["#1E3A8A", "#EA580C"]}
      style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
    >
      <StatusBar style="light" />
      <Animated.View
        style={{
          opacity: fadeAnim,
          transform: [{ scale: scaleAnim }],
          alignItems: "center",
        }}
      >
        {/* 3D Coin Logo */}
        <View
          style={{
            width: 120,
            height: 120,
            borderRadius: 60,
            backgroundColor: "#FFD700",
            justifyContent: "center",
            alignItems: "center",
            marginBottom: 24,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 8 },
            shadowOpacity: 0.3,
            shadowRadius: 16,
            elevation: 8,
          }}
        >
          <Text style={{ fontSize: 48, fontWeight: "bold", color: "#1E3A8A" }}>
            D
          </Text>
        </View>

        <Text
          style={{
            fontSize: 32,
            fontWeight: "bold",
            color: "#FFFFFF",
            marginBottom: 8,
            textShadowColor: "rgba(0,0,0,0.3)",
            textShadowOffset: { width: 0, height: 2 },
            textShadowRadius: 4,
          }}
        >
          Dropzy
        </Text>

        <Text
          style={{
            fontSize: 16,
            color: "rgba(255,255,255,0.8)",
            textAlign: "center",
            paddingHorizontal: 40,
            marginBottom: 40,
          }}
        >
          Refer & Earn with 3D Rewards
        </Text>

        <Text
          style={{
            fontSize: 14,
            color: "rgba(255,255,255,0.6)",
            textAlign: "center",
          }}
        >
          Tap anywhere to get started
        </Text>
      </Animated.View>
    </LinearGradient>
  );
}
