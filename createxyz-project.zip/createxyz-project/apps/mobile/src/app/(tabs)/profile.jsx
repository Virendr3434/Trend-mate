import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Animated,
  ScrollView,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { 
  User, 
  Settings, 
  LogOut, 
  Edit3, 
  Share2, 
  Trophy, 
  DollarSign,
  Users,
  Calendar,
  Star
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/utils/auth/useAuth';
import useUser from '@/utils/auth/useUser';

function Avatar3D({ size = 80 }) {
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const borderAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Continuous rotation
    const rotateAnimation = Animated.loop(
      Animated.timing(rotateAnim, {
        toValue: 1,
        duration: 8000,
        useNativeDriver: true,
      })
    );

    // Pulse animation
    const pulseAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.1,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    );

    // Border animation
    const borderAnimation = Animated.loop(
      Animated.timing(borderAnim, {
        toValue: 1,
        duration: 3000,
        useNativeDriver: true,
      })
    );

    rotateAnimation.start();
    pulseAnimation.start();
    borderAnimation.start();

    return () => {
      rotateAnimation.stop();
      pulseAnimation.stop();
      borderAnimation.stop();
    };
  }, []);

  const rotateInterpolate = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const borderOpacity = borderAnim.interpolate({
    inputRange: [0, 0.5, 1],
    outputRange: [0.3, 1, 0.3],
  });

  return (
    <View style={{ alignItems: 'center' }}>
      {/* Animated border */}
      <Animated.View
        style={{
          position: 'absolute',
          width: size + 16,
          height: size + 16,
          borderRadius: (size + 16) / 2,
          borderWidth: 3,
          borderColor: '#FFD700',
          opacity: borderOpacity,
        }}
      />
      
      {/* Main avatar */}
      <Animated.View
        style={{
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: '#FFD700',
          justifyContent: 'center',
          alignItems: 'center',
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 8 },
          shadowOpacity: 0.3,
          shadowRadius: 16,
          elevation: 8,
          transform: [
            { rotate: rotateInterpolate },
            { scale: pulseAnim },
          ],
        }}
      >
        <User size={size * 0.4} color="#1E3A8A" />
      </Animated.View>
    </View>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  };

  return (
    <TouchableOpacity onPress={handlePress} activeOpacity={0.9} style={{ flex: 1 }}>
      <Animated.View
        style={{
          transform: [{ scale: scaleAnim }],
        }}
      >
        <LinearGradient
          colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
          style={{
            borderRadius: 16,
            padding: 16,
            alignItems: 'center',
            borderWidth: 1,
            borderColor: 'rgba(255,255,255,0.3)',
          }}
        >
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: color,
              justifyContent: 'center',
              alignItems: 'center',
              marginBottom: 8,
            }}
          >
            <Icon size={20} color="#FFFFFF" />
          </View>
          
          <Text
            style={{
              fontSize: 20,
              fontWeight: 'bold',
              color: '#FFFFFF',
              marginBottom: 4,
            }}
          >
            {value}
          </Text>
          
          <Text
            style={{
              fontSize: 12,
              color: 'rgba(255,255,255,0.8)',
              textAlign: 'center',
            }}
          >
            {label}
          </Text>
        </LinearGradient>
      </Animated.View>
    </TouchableOpacity>
  );
}

function MenuButton({ icon: Icon, label, onPress, color = 'rgba(255,255,255,0.1)' }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.spring(scaleAnim, {
      toValue: 0.95,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
  };

  return (
    <TouchableOpacity
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      onPress={onPress}
      activeOpacity={0.9}
    >
      <Animated.View
        style={{
          transform: [{ scale: scaleAnim }],
        }}
      >
        <LinearGradient
          colors={['rgba(255,255,255,0.15)', 'rgba(255,255,255,0.05)']}
          style={{
            borderRadius: 12,
            padding: 16,
            flexDirection: 'row',
            alignItems: 'center',
            marginBottom: 12,
            borderWidth: 1,
            borderColor: 'rgba(255,255,255,0.2)',
          }}
        >
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: color,
              justifyContent: 'center',
              alignItems: 'center',
              marginRight: 16,
            }}
          >
            <Icon size={20} color="#FFFFFF" />
          </View>
          
          <Text
            style={{
              fontSize: 16,
              fontWeight: '600',
              color: '#FFFFFF',
              flex: 1,
            }}
          >
            {label}
          </Text>
          
          <View
            style={{
              width: 24,
              height: 24,
              borderRadius: 12,
              backgroundColor: 'rgba(255,255,255,0.2)',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <Text style={{ color: '#FFFFFF', fontSize: 12 }}>›</Text>
          </View>
        </LinearGradient>
      </Animated.View>
    </TouchableOpacity>
  );
}

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { data: user } = useUser();
  const { signOut } = useAuth();
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  // Fetch user profile
  const { data: userProfile } = useQuery({
    queryKey: ['userProfile'],
    queryFn: async () => {
      const response = await fetch('/api/users');
      if (!response.ok) throw new Error('Failed to fetch profile');
      return response.json();
    },
    enabled: !!user,
  });

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleSignOut = () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            await signOut();
          },
        },
      ]
    );
  };

  const handleEditProfile = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    // TODO: Navigate to edit profile screen
    Alert.alert('Edit Profile', 'Profile editing coming soon!');
  };

  const handleShareProfile = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    // TODO: Share profile functionality
    Alert.alert('Share Profile', 'Profile sharing coming soon!');
  };

  const handleSettings = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    // TODO: Navigate to settings screen
    Alert.alert('Settings', 'Settings screen coming soon!');
  };

  const joinDate = userProfile?.created_at 
    ? new Date(userProfile.created_at).toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long' 
      })
    : 'Recently';

  return (
    <LinearGradient
      colors={["#1E3A8A", "#EA580C"]}
      style={{ flex: 1 }}
    >
      <StatusBar style="light" />
      
      <Animated.View
        style={{
          flex: 1,
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }],
        }}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingTop: insets.top + 20,
            paddingBottom: insets.bottom + 100,
            paddingHorizontal: 20,
          }}
          showsVerticalScrollIndicator={false}
        >
          {/* Profile Header */}
          <View style={{ alignItems: 'center', marginBottom: 32 }}>
            <Avatar3D size={100} />
            
            <Text
              style={{
                fontSize: 24,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginTop: 16,
                marginBottom: 4,
              }}
            >
              {userProfile?.username || user?.name || 'Dropzy User'}
            </Text>
            
            <Text
              style={{
                fontSize: 16,
                color: 'rgba(255,255,255,0.8)',
                marginBottom: 8,
              }}
            >
              {user?.email}
            </Text>
            
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Calendar size={14} color="rgba(255,255,255,0.6)" />
              <Text
                style={{
                  fontSize: 14,
                  color: 'rgba(255,255,255,0.6)',
                  marginLeft: 6,
                }}
              >
                Joined {joinDate}
              </Text>
            </View>
            
            {/* Action Buttons */}
            <View style={{ flexDirection: 'row', marginTop: 20, gap: 12 }}>
              <TouchableOpacity
                onPress={handleEditProfile}
                style={{
                  backgroundColor: '#FFD700',
                  borderRadius: 12,
                  paddingHorizontal: 20,
                  paddingVertical: 10,
                  flexDirection: 'row',
                  alignItems: 'center',
                }}
              >
                <Edit3 size={16} color="#1E3A8A" />
                <Text
                  style={{
                    fontSize: 14,
                    fontWeight: 'bold',
                    color: '#1E3A8A',
                    marginLeft: 6,
                  }}
                >
                  Edit Profile
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                onPress={handleShareProfile}
                style={{
                  backgroundColor: 'rgba(255,255,255,0.2)',
                  borderRadius: 12,
                  paddingHorizontal: 20,
                  paddingVertical: 10,
                  flexDirection: 'row',
                  alignItems: 'center',
                  borderWidth: 1,
                  borderColor: 'rgba(255,255,255,0.3)',
                }}
              >
                <Share2 size={16} color="#FFFFFF" />
                <Text
                  style={{
                    fontSize: 14,
                    fontWeight: 'bold',
                    color: '#FFFFFF',
                    marginLeft: 6,
                  }}
                >
                  Share
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Stats Grid */}
          <View style={{ marginBottom: 32 }}>
            <Text
              style={{
                fontSize: 20,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 16,
              }}
            >
              Your Stats
            </Text>
            
            <View style={{ flexDirection: 'row', gap: 12, marginBottom: 12 }}>
              <StatCard
                icon={DollarSign}
                label="Total Earnings"
                value={`$${userProfile?.total_earnings || '0.00'}`}
                color="#10B981"
              />
              
              <StatCard
                icon={Users}
                label="Referrals"
                value={userProfile?.total_referrals || '0'}
                color="#8B5CF6"
              />
            </View>
            
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <StatCard
                icon={Trophy}
                label="Rank"
                value="#--"
                color="#F59E0B"
              />
              
              <StatCard
                icon={Star}
                label="Level"
                value="Beginner"
                color="#EF4444"
              />
            </View>
          </View>

          {/* Referral Code */}
          <View style={{ marginBottom: 32 }}>
            <Text
              style={{
                fontSize: 20,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 16,
              }}
            >
              Your Referral Code
            </Text>
            
            <LinearGradient
              colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
              style={{
                borderRadius: 16,
                padding: 20,
                borderWidth: 1,
                borderColor: 'rgba(255,255,255,0.3)',
                alignItems: 'center',
              }}
            >
              <Text
                style={{
                  fontSize: 24,
                  fontWeight: 'bold',
                  color: '#FFD700',
                  letterSpacing: 2,
                  marginBottom: 8,
                }}
              >
                {userProfile?.referral_code || 'Loading...'}
              </Text>
              
              <Text
                style={{
                  fontSize: 14,
                  color: 'rgba(255,255,255,0.8)',
                  textAlign: 'center',
                }}
              >
                Share this code to earn $10 for each referral
              </Text>
            </LinearGradient>
          </View>

          {/* Menu Options */}
          <View style={{ marginBottom: 32 }}>
            <Text
              style={{
                fontSize: 20,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 16,
              }}
            >
              Account
            </Text>
            
            <MenuButton
              icon={Settings}
              label="Settings"
              onPress={handleSettings}
              color="#6B7280"
            />
            
            <MenuButton
              icon={LogOut}
              label="Sign Out"
              onPress={handleSignOut}
              color="#EF4444"
            />
          </View>

          {/* App Info */}
          <View style={{ alignItems: 'center', marginTop: 20 }}>
            <Text
              style={{
                fontSize: 14,
                color: 'rgba(255,255,255,0.5)',
                textAlign: 'center',
              }}
            >
              Dropzy v1.0.0
            </Text>
            <Text
              style={{
                fontSize: 12,
                color: 'rgba(255,255,255,0.4)',
                textAlign: 'center',
                marginTop: 4,
              }}
            >
              The ultimate refer & earn app
            </Text>
          </View>
        </ScrollView>
      </Animated.View>
    </LinearGradient>
  );
}