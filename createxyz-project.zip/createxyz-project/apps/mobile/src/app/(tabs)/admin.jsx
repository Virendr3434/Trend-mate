import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Animated,
  ScrollView,
  TextInput,
  Alert,
  Modal,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { 
  Plus,
  BarChart3,
  Users,
  MessageSquare,
  Settings,
  TrendingUp,
  DollarSign,
  Eye,
  Edit,
  Trash2,
  Send
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import useUser from '@/utils/auth/useUser';

function StatCard({ icon: Icon, label, value, color, trend }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  };

  return (
    <TouchableOpacity onPress={handlePress} activeOpacity={0.9} style={{ flex: 1 }}>
      <Animated.View
        style={{
          transform: [{ scale: scaleAnim }],
        }}
      >
        <LinearGradient
          colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
          style={{
            borderRadius: 16,
            padding: 16,
            borderWidth: 1,
            borderColor: 'rgba(255,255,255,0.3)',
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
            <View
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: color,
                justifyContent: 'center',
                alignItems: 'center',
                marginRight: 8,
              }}
            >
              <Icon size={16} color="#FFFFFF" />
            </View>
            <Text
              style={{
                fontSize: 12,
                color: 'rgba(255,255,255,0.8)',
                flex: 1,
              }}
            >
              {label}
            </Text>
          </View>
          
          <Text
            style={{
              fontSize: 20,
              fontWeight: 'bold',
              color: '#FFFFFF',
              marginBottom: 4,
            }}
          >
            {value}
          </Text>
          
          {trend && (
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <TrendingUp size={12} color="#10B981" />
              <Text
                style={{
                  fontSize: 12,
                  color: '#10B981',
                  marginLeft: 4,
                }}
              >
                {trend}
              </Text>
            </View>
          )}
        </LinearGradient>
      </Animated.View>
    </TouchableOpacity>
  );
}

function PostCard({ post, onEdit, onDelete }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.spring(scaleAnim, {
      toValue: 0.98,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
  };

  const getPostTypeColor = () => {
    switch (post.post_type) {
      case 'offer': return '#FFD700';
      case 'announcement': return '#FF6B6B';
      default: return '#4ECDC4';
    }
  };

  return (
    <Animated.View
      style={{
        transform: [{ scale: scaleAnim }],
      }}
    >
      <LinearGradient
        colors={['rgba(255,255,255,0.15)', 'rgba(255,255,255,0.05)']}
        style={{
          borderRadius: 12,
          padding: 16,
          marginBottom: 12,
          borderWidth: 1,
          borderColor: 'rgba(255,255,255,0.2)',
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
          <View
            style={{
              width: 8,
              height: 8,
              borderRadius: 4,
              backgroundColor: getPostTypeColor(),
              marginRight: 8,
            }}
          />
          <Text
            style={{
              fontSize: 12,
              fontWeight: '600',
              color: getPostTypeColor(),
              textTransform: 'uppercase',
              letterSpacing: 1,
              flex: 1,
            }}
          >
            {post.post_type}
          </Text>
          
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <TouchableOpacity
              onPress={() => onEdit(post)}
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: 'rgba(255,255,255,0.2)',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Edit size={14} color="#FFFFFF" />
            </TouchableOpacity>
            
            <TouchableOpacity
              onPress={() => onDelete(post)}
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: 'rgba(239, 68, 68, 0.3)',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Trash2 size={14} color="#EF4444" />
            </TouchableOpacity>
          </View>
        </View>
        
        <Text
          style={{
            fontSize: 16,
            fontWeight: 'bold',
            color: '#FFFFFF',
            marginBottom: 8,
          }}
        >
          {post.title}
        </Text>
        
        <Text
          style={{
            fontSize: 14,
            color: 'rgba(255,255,255,0.8)',
            lineHeight: 20,
            marginBottom: 8,
          }}
        >
          {post.content}
        </Text>
        
        <Text
          style={{
            fontSize: 12,
            color: 'rgba(255,255,255,0.6)',
          }}
        >
          {new Date(post.created_at).toLocaleDateString()}
        </Text>
      </LinearGradient>
    </Animated.View>
  );
}

function CreatePostModal({ visible, onClose, onSubmit, editingPost = null }) {
  const [title, setTitle] = useState(editingPost?.title || '');
  const [content, setContent] = useState(editingPost?.content || '');
  const [postType, setPostType] = useState(editingPost?.post_type || 'general');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (editingPost) {
      setTitle(editingPost.title);
      setContent(editingPost.content);
      setPostType(editingPost.post_type);
    } else {
      setTitle('');
      setContent('');
      setPostType('general');
    }
  }, [editingPost]);

  const handleSubmit = async () => {
    if (!title.trim()) {
      Alert.alert('Error', 'Please enter a title');
      return;
    }

    setLoading(true);
    try {
      await onSubmit({
        title: title.trim(),
        content: content.trim(),
        post_type: postType,
      });
      onClose();
    } catch (error) {
      Alert.alert('Error', 'Failed to save post');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <LinearGradient
        colors={["#1E3A8A", "#EA580C"]}
        style={{ flex: 1 }}
      >
        <View style={{ flex: 1, padding: 20, paddingTop: 60 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 24 }}>
            <Text
              style={{
                fontSize: 24,
                fontWeight: 'bold',
                color: '#FFFFFF',
                flex: 1,
              }}
            >
              {editingPost ? 'Edit Post' : 'Create Post'}
            </Text>
            
            <TouchableOpacity
              onPress={onClose}
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: 'rgba(255,255,255,0.2)',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Text style={{ color: '#FFFFFF', fontSize: 18 }}>×</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
            {/* Post Type */}
            <Text
              style={{
                fontSize: 16,
                fontWeight: '600',
                color: '#FFFFFF',
                marginBottom: 12,
              }}
            >
              Post Type
            </Text>
            
            <View style={{ flexDirection: 'row', marginBottom: 24, gap: 8 }}>
              {['general', 'offer', 'announcement'].map((type) => (
                <TouchableOpacity
                  key={type}
                  onPress={() => setPostType(type)}
                  style={{
                    flex: 1,
                    backgroundColor: postType === type ? '#FFD700' : 'rgba(255,255,255,0.1)',
                    borderRadius: 8,
                    paddingVertical: 12,
                    alignItems: 'center',
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: 'bold',
                      color: postType === type ? '#1E3A8A' : 'rgba(255,255,255,0.8)',
                      textTransform: 'capitalize',
                    }}
                  >
                    {type}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Title */}
            <Text
              style={{
                fontSize: 16,
                fontWeight: '600',
                color: '#FFFFFF',
                marginBottom: 12,
              }}
            >
              Title
            </Text>
            
            <View
              style={{
                backgroundColor: 'rgba(255,255,255,0.15)',
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 12,
                marginBottom: 24,
                borderWidth: 1,
                borderColor: 'rgba(255,255,255,0.2)',
              }}
            >
              <TextInput
                value={title}
                onChangeText={setTitle}
                placeholder="Enter post title"
                placeholderTextColor="rgba(255,255,255,0.6)"
                style={{
                  fontSize: 16,
                  color: '#FFFFFF',
                }}
              />
            </View>

            {/* Content */}
            <Text
              style={{
                fontSize: 16,
                fontWeight: '600',
                color: '#FFFFFF',
                marginBottom: 12,
              }}
            >
              Content
            </Text>
            
            <View
              style={{
                backgroundColor: 'rgba(255,255,255,0.15)',
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 12,
                marginBottom: 24,
                borderWidth: 1,
                borderColor: 'rgba(255,255,255,0.2)',
                minHeight: 120,
              }}
            >
              <TextInput
                value={content}
                onChangeText={setContent}
                placeholder="Enter post content"
                placeholderTextColor="rgba(255,255,255,0.6)"
                style={{
                  fontSize: 16,
                  color: '#FFFFFF',
                  textAlignVertical: 'top',
                }}
                multiline
              />
            </View>
          </ScrollView>

          {/* Submit Button */}
          <TouchableOpacity
            onPress={handleSubmit}
            disabled={loading}
            style={{
              backgroundColor: '#FFD700',
              borderRadius: 12,
              paddingVertical: 16,
              alignItems: 'center',
              flexDirection: 'row',
              justifyContent: 'center',
              opacity: loading ? 0.7 : 1,
            }}
          >
            <Send size={20} color="#1E3A8A" />
            <Text
              style={{
                fontSize: 16,
                fontWeight: 'bold',
                color: '#1E3A8A',
                marginLeft: 8,
              }}
            >
              {loading ? 'Saving...' : editingPost ? 'Update Post' : 'Create Post'}
            </Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    </Modal>
  );
}

export default function AdminScreen() {
  const insets = useSafeAreaInsets();
  const { data: user } = useUser();
  const queryClient = useQueryClient();
  
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingPost, setEditingPost] = useState(null);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  // Fetch posts
  const { data: posts = [], refetch: refetchPosts } = useQuery({
    queryKey: ['posts'],
    queryFn: async () => {
      const response = await fetch('/api/posts');
      if (!response.ok) throw new Error('Failed to fetch posts');
      return response.json();
    },
  });

  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (postData) => {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(postData),
      });
      if (!response.ok) throw new Error('Failed to create post');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['posts']);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    },
  });

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleCreatePost = () => {
    setEditingPost(null);
    setShowCreateModal(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleEditPost = (post) => {
    setEditingPost(post);
    setShowCreateModal(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleDeletePost = (post) => {
    Alert.alert(
      'Delete Post',
      'Are you sure you want to delete this post?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            // TODO: Implement delete functionality
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            Alert.alert('Delete', 'Delete functionality coming soon!');
          },
        },
      ]
    );
  };

  const handleSubmitPost = async (postData) => {
    await createPostMutation.mutateAsync(postData);
  };

  return (
    <LinearGradient
      colors={["#1E3A8A", "#EA580C"]}
      style={{ flex: 1 }}
    >
      <StatusBar style="light" />
      
      <Animated.View
        style={{
          flex: 1,
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }],
        }}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingTop: insets.top + 20,
            paddingBottom: insets.bottom + 100,
            paddingHorizontal: 20,
          }}
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View style={{ alignItems: 'center', marginBottom: 32 }}>
            <View
              style={{
                width: 80,
                height: 80,
                borderRadius: 40,
                backgroundColor: '#FFD700',
                justifyContent: 'center',
                alignItems: 'center',
                marginBottom: 16,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 8 },
                shadowOpacity: 0.3,
                shadowRadius: 16,
                elevation: 8,
              }}
            >
              <BarChart3 size={32} color="#1E3A8A" />
            </View>
            
            <Text
              style={{
                fontSize: 28,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 8,
                textAlign: 'center',
              }}
            >
              DashX Admin
            </Text>
            
            <Text
              style={{
                fontSize: 16,
                color: 'rgba(255,255,255,0.8)',
                textAlign: 'center',
              }}
            >
              Manage your refer & earn platform
            </Text>
          </View>

          {/* Stats Grid */}
          <View style={{ marginBottom: 32 }}>
            <Text
              style={{
                fontSize: 20,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 16,
              }}
            >
              Analytics Overview
            </Text>
            
            <View style={{ flexDirection: 'row', gap: 12, marginBottom: 12 }}>
              <StatCard
                icon={Users}
                label="Total Users"
                value="1,234"
                color="#8B5CF6"
                trend="+12%"
              />
              
              <StatCard
                icon={DollarSign}
                label="Total Payouts"
                value="$45,678"
                color="#10B981"
                trend="+8%"
              />
            </View>
            
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <StatCard
                icon={TrendingUp}
                label="Referrals"
                value="567"
                color="#F59E0B"
                trend="+15%"
              />
              
              <StatCard
                icon={MessageSquare}
                label="Posts"
                value={posts.length.toString()}
                color="#EF4444"
              />
            </View>
          </View>

          {/* Posts Management */}
          <View style={{ marginBottom: 32 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
              <Text
                style={{
                  fontSize: 20,
                  fontWeight: 'bold',
                  color: '#FFFFFF',
                  flex: 1,
                }}
              >
                Manage Posts
              </Text>
              
              <TouchableOpacity
                onPress={handleCreatePost}
                style={{
                  backgroundColor: '#FFD700',
                  borderRadius: 12,
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  flexDirection: 'row',
                  alignItems: 'center',
                }}
              >
                <Plus size={16} color="#1E3A8A" />
                <Text
                  style={{
                    fontSize: 14,
                    fontWeight: 'bold',
                    color: '#1E3A8A',
                    marginLeft: 6,
                  }}
                >
                  New Post
                </Text>
              </TouchableOpacity>
            </View>
            
            {posts.length > 0 ? (
              posts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  onEdit={handleEditPost}
                  onDelete={handleDeletePost}
                />
              ))
            ) : (
              <View
                style={{
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  borderRadius: 16,
                  padding: 20,
                  alignItems: 'center',
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    color: 'rgba(255,255,255,0.7)',
                    textAlign: 'center',
                  }}
                >
                  No posts yet. Create your first post to engage users!
                </Text>
              </View>
            )}
          </View>

          {/* Quick Actions */}
          <View>
            <Text
              style={{
                fontSize: 20,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 16,
              }}
            >
              Quick Actions
            </Text>
            
            <View style={{ gap: 12 }}>
              <TouchableOpacity
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  Alert.alert('Analytics', 'Detailed analytics coming soon!');
                }}
                style={{
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  borderRadius: 12,
                  padding: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                  borderWidth: 1,
                  borderColor: 'rgba(255,255,255,0.2)',
                }}
              >
                <Eye size={20} color="#FFFFFF" />
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: '600',
                    color: '#FFFFFF',
                    marginLeft: 12,
                  }}
                >
                  View Detailed Analytics
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  Alert.alert('Settings', 'Admin settings coming soon!');
                }}
                style={{
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  borderRadius: 12,
                  padding: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                  borderWidth: 1,
                  borderColor: 'rgba(255,255,255,0.2)',
                }}
              >
                <Settings size={20} color="#FFFFFF" />
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: '600',
                    color: '#FFFFFF',
                    marginLeft: 12,
                  }}
                >
                  Platform Settings
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </Animated.View>

      {/* Create/Edit Post Modal */}
      <CreatePostModal
        visible={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSubmit={handleSubmitPost}
        editingPost={editingPost}
      />
    </LinearGradient>
  );
}