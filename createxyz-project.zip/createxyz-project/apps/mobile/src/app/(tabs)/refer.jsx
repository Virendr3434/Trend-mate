import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Animated,
  Share,
  Clipboard,
  Alert,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Share2, Copy, MessageCircle, Mail, Users, Gift } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useQuery } from '@tanstack/react-query';
import useUser from '@/utils/auth/useUser';

function ConfettiParticle({ delay = 0 }) {
  const translateY = useRef(new Animated.Value(-50)).current;
  const translateX = useRef(new Animated.Value(Math.random() * 200 - 100)).current;
  const rotate = useRef(new Animated.Value(0)).current;
  const opacity = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const animation = Animated.parallel([
      Animated.timing(translateY, {
        toValue: 400,
        duration: 2000,
        delay,
        useNativeDriver: true,
      }),
      Animated.timing(rotate, {
        toValue: 360,
        duration: 2000,
        delay,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 0,
        duration: 2000,
        delay,
        useNativeDriver: true,
      }),
    ]);

    animation.start();
  }, [delay]);

  const colors = ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'];
  const color = colors[Math.floor(Math.random() * colors.length)];

  return (
    <Animated.View
      style={{
        position: 'absolute',
        top: 0,
        left: '50%',
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: color,
        transform: [
          { translateX },
          { translateY },
          { rotate: rotate.interpolate({
            inputRange: [0, 360],
            outputRange: ['0deg', '360deg'],
          }) },
        ],
        opacity,
      }}
    />
  );
}

function ShareButton({ icon: Icon, label, color, onPress }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const bounceAnim = useRef(new Animated.Value(0)).current;

  const handlePressIn = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.spring(scaleAnim, {
      toValue: 0.9,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
  };

  const handlePress = () => {
    // Bounce animation
    Animated.sequence([
      Animated.timing(bounceAnim, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(bounceAnim, {
        toValue: 0,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();

    onPress();
  };

  return (
    <TouchableOpacity
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      onPress={handlePress}
      activeOpacity={0.9}
      style={{ alignItems: 'center', flex: 1 }}
    >
      <Animated.View
        style={{
          transform: [
            { scale: scaleAnim },
            { translateY: bounceAnim.interpolate({
              inputRange: [0, 1],
              outputRange: [0, -10],
            }) },
          ],
        }}
      >
        <LinearGradient
          colors={[color, `${color}CC`]}
          style={{
            width: 60,
            height: 60,
            borderRadius: 30,
            justifyContent: 'center',
            alignItems: 'center',
            marginBottom: 8,
            shadowColor: color,
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.3,
            shadowRadius: 8,
            elevation: 8,
          }}
        >
          <Icon size={24} color="#FFFFFF" />
        </LinearGradient>
      </Animated.View>
      
      <Text
        style={{
          fontSize: 12,
          fontWeight: '600',
          color: 'rgba(255,255,255,0.9)',
          textAlign: 'center',
        }}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );
}

export default function ReferScreen() {
  const insets = useSafeAreaInsets();
  const { data: user } = useUser();
  const [showConfetti, setShowConfetti] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const coinRotation = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  // Fetch user profile
  const { data: userProfile } = useQuery({
    queryKey: ['userProfile'],
    queryFn: async () => {
      const response = await fetch('/api/users');
      if (!response.ok) throw new Error('Failed to fetch profile');
      return response.json();
    },
    enabled: !!user,
  });

  useEffect(() => {
    // Entrance animation
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();

    // Continuous coin rotation
    const rotateAnimation = Animated.loop(
      Animated.timing(coinRotation, {
        toValue: 1,
        duration: 4000,
        useNativeDriver: true,
      })
    );
    rotateAnimation.start();

    // Pulse animation for referral code
    const pulseAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.05,
          duration: 1500,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true,
        }),
      ])
    );
    pulseAnimation.start();

    return () => {
      rotateAnimation.stop();
      pulseAnimation.stop();
    };
  }, []);

  const triggerConfetti = () => {
    setShowConfetti(true);
    setTimeout(() => setShowConfetti(false), 2000);
  };

  const copyReferralCode = async () => {
    if (!userProfile?.referral_code) return;

    try {
      await Clipboard.setStringAsync(userProfile.referral_code);
      setCopiedCode(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      triggerConfetti();
      
      setTimeout(() => setCopiedCode(false), 2000);
    } catch (error) {
      Alert.alert('Error', 'Failed to copy referral code');
    }
  };

  const shareReferralCode = async () => {
    if (!userProfile?.referral_code) return;

    try {
      const message = `🎉 Join me on Dropzy and start earning rewards! Use my referral code: ${userProfile.referral_code}\n\nGet $5 bonus when you sign up! 💰`;
      
      await Share.share({
        message,
        title: 'Join Dropzy - Refer & Earn App',
      });

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      triggerConfetti();
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  const shareViaWhatsApp = () => {
    // In a real app, you'd use Linking to open WhatsApp
    shareReferralCode();
  };

  const shareViaEmail = () => {
    // In a real app, you'd use Linking to open email
    shareReferralCode();
  };

  const shareViaSMS = () => {
    // In a real app, you'd use Linking to open SMS
    shareReferralCode();
  };

  const coinRotationInterpolate = coinRotation.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  return (
    <LinearGradient
      colors={["#1E3A8A", "#EA580C"]}
      style={{ flex: 1 }}
    >
      <StatusBar style="light" />
      
      {/* Confetti */}
      {showConfetti && (
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 1000 }}>
          {Array.from({ length: 20 }).map((_, i) => (
            <ConfettiParticle key={i} delay={i * 100} />
          ))}
        </View>
      )}

      <Animated.View
        style={{
          flex: 1,
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }],
        }}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingTop: insets.top + 20,
            paddingBottom: insets.bottom + 100,
            paddingHorizontal: 20,
          }}
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View style={{ alignItems: 'center', marginBottom: 40 }}>
            <Animated.View
              style={{
                width: 100,
                height: 100,
                borderRadius: 50,
                backgroundColor: '#FFD700',
                justifyContent: 'center',
                alignItems: 'center',
                marginBottom: 24,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 8 },
                shadowOpacity: 0.3,
                shadowRadius: 16,
                elevation: 8,
                transform: [{ rotate: coinRotationInterpolate }],
              }}
            >
              <Gift size={40} color="#1E3A8A" />
            </Animated.View>
            
            <Text
              style={{
                fontSize: 28,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 8,
                textAlign: 'center',
              }}
            >
              Refer & Earn
            </Text>
            
            <Text
              style={{
                fontSize: 16,
                color: 'rgba(255,255,255,0.8)',
                textAlign: 'center',
                lineHeight: 24,
              }}
            >
              Share your code and earn $10 for each friend who joins!
            </Text>
          </View>

          {/* Referral Code Card */}
          <Animated.View
            style={{
              transform: [{ scale: pulseAnim }],
              marginBottom: 32,
            }}
          >
            <LinearGradient
              colors={['rgba(255,255,255,0.25)', 'rgba(255,255,255,0.15)']}
              style={{
                borderRadius: 20,
                padding: 24,
                borderWidth: 2,
                borderColor: 'rgba(255,255,255,0.3)',
                alignItems: 'center',
              }}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: '600',
                  color: 'rgba(255,255,255,0.9)',
                  marginBottom: 12,
                }}
              >
                Your Referral Code
              </Text>
              
              <Text
                style={{
                  fontSize: 32,
                  fontWeight: 'bold',
                  color: '#FFD700',
                  letterSpacing: 4,
                  marginBottom: 20,
                  textShadowColor: 'rgba(0,0,0,0.3)',
                  textShadowOffset: { width: 0, height: 2 },
                  textShadowRadius: 4,
                }}
              >
                {userProfile?.referral_code || 'Loading...'}
              </Text>
              
              <TouchableOpacity
                onPress={copyReferralCode}
                style={{
                  backgroundColor: copiedCode ? '#10B981' : '#FFD700',
                  borderRadius: 12,
                  paddingHorizontal: 20,
                  paddingVertical: 12,
                  flexDirection: 'row',
                  alignItems: 'center',
                }}
              >
                <Copy size={16} color="#1E3A8A" />
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: 'bold',
                    color: '#1E3A8A',
                    marginLeft: 8,
                  }}
                >
                  {copiedCode ? 'Copied!' : 'Copy Code'}
                </Text>
              </TouchableOpacity>
            </LinearGradient>
          </Animated.View>

          {/* Share Options */}
          <View style={{ marginBottom: 32 }}>
            <Text
              style={{
                fontSize: 20,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 20,
                textAlign: 'center',
              }}
            >
              Share Your Code
            </Text>
            
            <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginBottom: 24 }}>
              <ShareButton
                icon={Share2}
                label="Share"
                color="#4ECDC4"
                onPress={shareReferralCode}
              />
              
              <ShareButton
                icon={MessageCircle}
                label="WhatsApp"
                color="#25D366"
                onPress={shareViaWhatsApp}
              />
              
              <ShareButton
                icon={Mail}
                label="Email"
                color="#EA4335"
                onPress={shareViaEmail}
              />
              
              <ShareButton
                icon={Users}
                label="SMS"
                color="#007AFF"
                onPress={shareViaSMS}
              />
            </View>
          </View>

          {/* Stats */}
          <LinearGradient
            colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
            style={{
              borderRadius: 16,
              padding: 20,
              marginBottom: 32,
              borderWidth: 1,
              borderColor: 'rgba(255,255,255,0.3)',
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 16,
                textAlign: 'center',
              }}
            >
              Your Referral Stats
            </Text>
            
            <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
              <View style={{ alignItems: 'center' }}>
                <Text
                  style={{
                    fontSize: 24,
                    fontWeight: 'bold',
                    color: '#FFD700',
                  }}
                >
                  {userProfile?.total_referrals || '0'}
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: 'rgba(255,255,255,0.8)',
                  }}
                >
                  Referrals
                </Text>
              </View>
              
              <View style={{ alignItems: 'center' }}>
                <Text
                  style={{
                    fontSize: 24,
                    fontWeight: 'bold',
                    color: '#10B981',
                  }}
                >
                  ${userProfile?.total_earnings || '0.00'}
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: 'rgba(255,255,255,0.8)',
                  }}
                >
                  Earned
                </Text>
              </View>
            </View>
          </LinearGradient>

          {/* How it Works */}
          <View>
            <Text
              style={{
                fontSize: 20,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 16,
                textAlign: 'center',
              }}
            >
              How It Works
            </Text>
            
            <View style={{ gap: 16 }}>
              {[
                { step: '1', title: 'Share Your Code', desc: 'Send your referral code to friends' },
                { step: '2', title: 'Friend Signs Up', desc: 'They use your code when joining' },
                { step: '3', title: 'Earn Rewards', desc: 'Get $10 for each successful referral' },
              ].map((item, index) => (
                <View
                  key={index}
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.1)',
                    borderRadius: 12,
                    padding: 16,
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                >
                  <View
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 16,
                      backgroundColor: '#FFD700',
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginRight: 16,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 16,
                        fontWeight: 'bold',
                        color: '#1E3A8A',
                      }}
                    >
                      {item.step}
                    </Text>
                  </View>
                  
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 16,
                        fontWeight: 'bold',
                        color: '#FFFFFF',
                        marginBottom: 4,
                      }}
                    >
                      {item.title}
                    </Text>
                    <Text
                      style={{
                        fontSize: 14,
                        color: 'rgba(255,255,255,0.8)',
                      }}
                    >
                      {item.desc}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        </ScrollView>
      </Animated.View>
    </LinearGradient>
  );
}