import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Animated,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Trophy, Crown, Medal, Star, DollarSign, Clock } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useQuery } from '@tanstack/react-query';
import useUser from '@/utils/auth/useUser';

function CoinRainParticle({ delay = 0 }) {
  const translateY = useRef(new Animated.Value(-100)).current;
  const translateX = useRef(new Animated.Value(Math.random() * 300)).current;
  const rotate = useRef(new Animated.Value(0)).current;
  const opacity = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const animation = Animated.parallel([
      Animated.timing(translateY, {
        toValue: 600,
        duration: 3000,
        delay,
        useNativeDriver: true,
      }),
      Animated.timing(rotate, {
        toValue: 720,
        duration: 3000,
        delay,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 0,
        duration: 3000,
        delay,
        useNativeDriver: true,
      }),
    ]);

    animation.start();
  }, [delay]);

  return (
    <Animated.View
      style={{
        position: 'absolute',
        top: 0,
        width: 20,
        height: 20,
        borderRadius: 10,
        backgroundColor: '#FFD700',
        transform: [
          { translateX },
          { translateY },
          { rotate: rotate.interpolate({
            inputRange: [0, 720],
            outputRange: ['0deg', '720deg'],
          }) },
        ],
        opacity,
        shadowColor: '#FFD700',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.5,
        shadowRadius: 4,
        elevation: 4,
      }}
    >
      <Text style={{ fontSize: 12, textAlign: 'center', color: '#1E3A8A', fontWeight: 'bold' }}>
        $
      </Text>
    </Animated.View>
  );
}

function LeaderboardCard({ user, rank, isCurrentUser = false }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const glimmerAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (rank <= 3) {
      const glimmerAnimation = Animated.loop(
        Animated.sequence([
          Animated.timing(glimmerAnim, {
            toValue: 1,
            duration: 2000,
            useNativeDriver: true,
          }),
          Animated.timing(glimmerAnim, {
            toValue: 0,
            duration: 2000,
            useNativeDriver: true,
          }),
        ])
      );
      glimmerAnimation.start();
      return () => glimmerAnimation.stop();
    }
  }, [rank]);

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const getRankIcon = () => {
    switch (rank) {
      case 1: return <Crown size={24} color="#FFD700" />;
      case 2: return <Medal size={24} color="#C0C0C0" />;
      case 3: return <Medal size={24} color="#CD7F32" />;
      default: return <Trophy size={20} color="rgba(255,255,255,0.6)" />;
    }
  };

  const getRankColor = () => {
    switch (rank) {
      case 1: return '#FFD700';
      case 2: return '#C0C0C0';
      case 3: return '#CD7F32';
      default: return 'rgba(255,255,255,0.1)';
    }
  };

  return (
    <TouchableOpacity onPress={handlePress} activeOpacity={0.9}>
      <Animated.View
        style={{
          transform: [{ scale: scaleAnim }],
        }}
      >
        <LinearGradient
          colors={
            isCurrentUser
              ? ['rgba(255,215,0,0.3)', 'rgba(255,215,0,0.1)']
              : rank <= 3
              ? ['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']
              : ['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.05)']
          }
          style={{
            borderRadius: 16,
            padding: 16,
            marginBottom: 12,
            borderWidth: isCurrentUser ? 2 : 1,
            borderColor: isCurrentUser ? '#FFD700' : 'rgba(255,255,255,0.2)',
            flexDirection: 'row',
            alignItems: 'center',
          }}
        >
          {/* Glimmer effect for top 3 */}
          {rank <= 3 && (
            <Animated.View
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                borderRadius: 16,
                opacity: glimmerAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, 0.3],
                }),
                backgroundColor: getRankColor(),
              }}
            />
          )}

          {/* Rank */}
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: getRankColor(),
              justifyContent: 'center',
              alignItems: 'center',
              marginRight: 16,
            }}
          >
            {rank <= 3 ? (
              getRankIcon()
            ) : (
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: 'bold',
                  color: '#FFFFFF',
                }}
              >
                {rank}
              </Text>
            )}
          </View>

          {/* User Info */}
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 16,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 4,
              }}
            >
              {user.username || 'Anonymous'}
              {isCurrentUser && (
                <Text style={{ color: '#FFD700', fontSize: 14 }}> (You)</Text>
              )}
            </Text>
            <Text
              style={{
                fontSize: 14,
                color: 'rgba(255,255,255,0.7)',
              }}
            >
              {user.total_referrals} referrals
            </Text>
          </View>

          {/* Earnings */}
          <View style={{ alignItems: 'flex-end' }}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: 'bold',
                color: '#10B981',
              }}
            >
              ${user.total_earnings}
            </Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 2 }}>
              <Star size={12} color="#FFD700" />
              <Text
                style={{
                  fontSize: 12,
                  color: 'rgba(255,255,255,0.6)',
                  marginLeft: 4,
                }}
              >
                Rank #{rank}
              </Text>
            </View>
          </View>
        </LinearGradient>
      </Animated.View>
    </TouchableOpacity>
  );
}

function RewardCard({ reward }) {
  const getRewardIcon = () => {
    switch (reward.reward_type) {
      case 'referral_bonus': return <DollarSign size={20} color="#10B981" />;
      case 'signup_bonus': return <Star size={20} color="#FFD700" />;
      default: return <Trophy size={20} color="#8B5CF6" />;
    }
  };

  const getStatusColor = () => {
    switch (reward.status) {
      case 'paid': return '#10B981';
      case 'pending': return '#F59E0B';
      case 'cancelled': return '#EF4444';
      default: return '#6B7280';
    }
  };

  return (
    <LinearGradient
      colors={['rgba(255,255,255,0.15)', 'rgba(255,255,255,0.05)']}
      style={{
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.2)',
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
        <View
          style={{
            width: 32,
            height: 32,
            borderRadius: 16,
            backgroundColor: 'rgba(255,255,255,0.2)',
            justifyContent: 'center',
            alignItems: 'center',
            marginRight: 12,
          }}
        >
          {getRewardIcon()}
        </View>
        
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontSize: 16,
              fontWeight: 'bold',
              color: '#FFFFFF',
            }}
          >
            ${reward.amount}
          </Text>
          <Text
            style={{
              fontSize: 12,
              color: 'rgba(255,255,255,0.7)',
              textTransform: 'capitalize',
            }}
          >
            {reward.reward_type.replace('_', ' ')}
          </Text>
        </View>
        
        <View style={{ alignItems: 'flex-end' }}>
          <View
            style={{
              backgroundColor: getStatusColor(),
              borderRadius: 8,
              paddingHorizontal: 8,
              paddingVertical: 4,
              marginBottom: 4,
            }}
          >
            <Text
              style={{
                fontSize: 10,
                fontWeight: 'bold',
                color: '#FFFFFF',
                textTransform: 'uppercase',
              }}
            >
              {reward.status}
            </Text>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Clock size={10} color="rgba(255,255,255,0.5)" />
            <Text
              style={{
                fontSize: 10,
                color: 'rgba(255,255,255,0.5)',
                marginLeft: 4,
              }}
            >
              {new Date(reward.created_at).toLocaleDateString()}
            </Text>
          </View>
        </View>
      </View>
      
      {reward.description && (
        <Text
          style={{
            fontSize: 14,
            color: 'rgba(255,255,255,0.8)',
            lineHeight: 18,
          }}
        >
          {reward.description}
        </Text>
      )}
    </LinearGradient>
  );
}

export default function RewardsScreen() {
  const insets = useSafeAreaInsets();
  const { data: user } = useUser();
  const [refreshing, setRefreshing] = useState(false);
  const [showCoinRain, setShowCoinRain] = useState(false);
  const [activeTab, setActiveTab] = useState('leaderboard'); // leaderboard, rewards
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  // Fetch user profile
  const { data: userProfile, refetch: refetchProfile } = useQuery({
    queryKey: ['userProfile'],
    queryFn: async () => {
      const response = await fetch('/api/users');
      if (!response.ok) throw new Error('Failed to fetch profile');
      return response.json();
    },
    enabled: !!user,
  });

  // Fetch leaderboard
  const { data: leaderboard = [], refetch: refetchLeaderboard } = useQuery({
    queryKey: ['leaderboard'],
    queryFn: async () => {
      const response = await fetch('/api/leaderboard');
      if (!response.ok) throw new Error('Failed to fetch leaderboard');
      return response.json();
    },
  });

  // Fetch user rewards
  const { data: rewards = [], refetch: refetchRewards } = useQuery({
    queryKey: ['rewards'],
    queryFn: async () => {
      const response = await fetch('/api/rewards');
      if (!response.ok) throw new Error('Failed to fetch rewards');
      return response.json();
    },
    enabled: !!user,
  });

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await Promise.all([refetchProfile(), refetchLeaderboard(), refetchRewards()]);
    setRefreshing(false);
  };

  const triggerCoinRain = () => {
    setShowCoinRain(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setTimeout(() => setShowCoinRain(false), 3000);
  };

  const currentUserRank = leaderboard.findIndex(
    (item) => item.id === userProfile?.id
  ) + 1;

  return (
    <LinearGradient
      colors={["#1E3A8A", "#EA580C"]}
      style={{ flex: 1 }}
    >
      <StatusBar style="light" />
      
      {/* Coin Rain */}
      {showCoinRain && (
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 1000 }}>
          {Array.from({ length: 15 }).map((_, i) => (
            <CoinRainParticle key={i} delay={i * 200} />
          ))}
        </View>
      )}

      <Animated.View
        style={{
          flex: 1,
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }],
        }}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingTop: insets.top + 20,
            paddingBottom: insets.bottom + 100,
            paddingHorizontal: 20,
          }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#FFD700"
              colors={["#FFD700"]}
            />
          }
        >
          {/* Header */}
          <View style={{ alignItems: 'center', marginBottom: 32 }}>
            <TouchableOpacity onPress={triggerCoinRain}>
              <View
                style={{
                  width: 80,
                  height: 80,
                  borderRadius: 40,
                  backgroundColor: '#FFD700',
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginBottom: 16,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 8 },
                  shadowOpacity: 0.3,
                  shadowRadius: 16,
                  elevation: 8,
                }}
              >
                <Trophy size={32} color="#1E3A8A" />
              </View>
            </TouchableOpacity>
            
            <Text
              style={{
                fontSize: 28,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 8,
                textAlign: 'center',
              }}
            >
              Rewards & Leaderboard
            </Text>
            
            <Text
              style={{
                fontSize: 16,
                color: 'rgba(255,255,255,0.8)',
                textAlign: 'center',
              }}
            >
              Compete with others and track your earnings
            </Text>
          </View>

          {/* Tab Selector */}
          <View
            style={{
              flexDirection: 'row',
              backgroundColor: 'rgba(255,255,255,0.1)',
              borderRadius: 12,
              padding: 4,
              marginBottom: 24,
            }}
          >
            <TouchableOpacity
              onPress={() => {
                setActiveTab('leaderboard');
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }}
              style={{
                flex: 1,
                backgroundColor: activeTab === 'leaderboard' ? '#FFD700' : 'transparent',
                borderRadius: 8,
                paddingVertical: 12,
                alignItems: 'center',
              }}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: 'bold',
                  color: activeTab === 'leaderboard' ? '#1E3A8A' : 'rgba(255,255,255,0.7)',
                }}
              >
                Leaderboard
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              onPress={() => {
                setActiveTab('rewards');
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }}
              style={{
                flex: 1,
                backgroundColor: activeTab === 'rewards' ? '#FFD700' : 'transparent',
                borderRadius: 8,
                paddingVertical: 12,
                alignItems: 'center',
              }}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: 'bold',
                  color: activeTab === 'rewards' ? '#1E3A8A' : 'rgba(255,255,255,0.7)',
                }}
              >
                My Rewards
              </Text>
            </TouchableOpacity>
          </View>

          {/* Content */}
          {activeTab === 'leaderboard' ? (
            <View>
              {/* Current User Rank */}
              {currentUserRank > 0 && (
                <View style={{ marginBottom: 24 }}>
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: 'bold',
                      color: '#FFFFFF',
                      marginBottom: 12,
                    }}
                  >
                    Your Ranking
                  </Text>
                  <LeaderboardCard
                    user={userProfile}
                    rank={currentUserRank}
                    isCurrentUser={true}
                  />
                </View>
              )}

              {/* Top Users */}
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: 'bold',
                  color: '#FFFFFF',
                  marginBottom: 16,
                }}
              >
                Top Earners
              </Text>
              
              {leaderboard.length > 0 ? (
                leaderboard.slice(0, 10).map((user, index) => (
                  <LeaderboardCard
                    key={user.id}
                    user={user}
                    rank={index + 1}
                    isCurrentUser={user.id === userProfile?.id}
                  />
                ))
              ) : (
                <View
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.1)',
                    borderRadius: 16,
                    padding: 20,
                    alignItems: 'center',
                  }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      color: 'rgba(255,255,255,0.7)',
                      textAlign: 'center',
                    }}
                  >
                    No leaderboard data yet. Start referring to see rankings!
                  </Text>
                </View>
              )}
            </View>
          ) : (
            <View>
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: 'bold',
                  color: '#FFFFFF',
                  marginBottom: 16,
                }}
              >
                Your Reward History
              </Text>
              
              {rewards.length > 0 ? (
                rewards.map((reward) => (
                  <RewardCard key={reward.id} reward={reward} />
                ))
              ) : (
                <View
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.1)',
                    borderRadius: 16,
                    padding: 20,
                    alignItems: 'center',
                  }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      color: 'rgba(255,255,255,0.7)',
                      textAlign: 'center',
                    }}
                  >
                    No rewards yet. Start referring friends to earn rewards!
                  </Text>
                </View>
              )}
            </View>
          )}
        </ScrollView>
      </Animated.View>
    </LinearGradient>
  );
}