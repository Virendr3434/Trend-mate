import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Animated,
  Dimensions,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Bell, TrendingUp, Users, DollarSign, Share2 } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useQuery } from '@tanstack/react-query';
import useUser from '@/utils/auth/useUser';

const { width: screenWidth } = Dimensions.get('window');

function StatsCard({ title, value, subtitle, icon: Icon, color, onPress }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.spring(scaleAnim, {
      toValue: 0.95,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
  };

  return (
    <TouchableOpacity
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      onPress={onPress}
      activeOpacity={0.9}
    >
      <Animated.View
        style={{
          transform: [{ scale: scaleAnim }],
        }}
      >
        <LinearGradient
          colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
          style={{
            borderRadius: 20,
            padding: 20,
            marginBottom: 16,
            borderWidth: 1,
            borderColor: 'rgba(255,255,255,0.3)',
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: color,
                justifyContent: 'center',
                alignItems: 'center',
                marginRight: 12,
              }}
            >
              <Icon size={20} color="#FFFFFF" />
            </View>
            <Text
              style={{
                fontSize: 16,
                fontWeight: '600',
                color: 'rgba(255,255,255,0.9)',
                flex: 1,
              }}
            >
              {title}
            </Text>
          </View>
          
          <Text
            style={{
              fontSize: 28,
              fontWeight: 'bold',
              color: '#FFFFFF',
              marginBottom: 4,
            }}
          >
            {value}
          </Text>
          
          <Text
            style={{
              fontSize: 14,
              color: 'rgba(255,255,255,0.7)',
            }}
          >
            {subtitle}
          </Text>
        </LinearGradient>
      </Animated.View>
    </TouchableOpacity>
  );
}

function PostCard({ post }) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.spring(scaleAnim, {
      toValue: 0.98,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
  };

  const getPostTypeColor = () => {
    switch (post.post_type) {
      case 'offer': return '#FFD700';
      case 'announcement': return '#FF6B6B';
      default: return '#4ECDC4';
    }
  };

  return (
    <TouchableOpacity
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      activeOpacity={0.9}
    >
      <Animated.View
        style={{
          transform: [{ scale: scaleAnim }],
        }}
      >
        <LinearGradient
          colors={['rgba(255,255,255,0.15)', 'rgba(255,255,255,0.05)']}
          style={{
            borderRadius: 16,
            padding: 16,
            marginBottom: 12,
            borderWidth: 1,
            borderColor: 'rgba(255,255,255,0.2)',
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
            <View
              style={{
                width: 8,
                height: 8,
                borderRadius: 4,
                backgroundColor: getPostTypeColor(),
                marginRight: 8,
              }}
            />
            <Text
              style={{
                fontSize: 12,
                fontWeight: '600',
                color: getPostTypeColor(),
                textTransform: 'uppercase',
                letterSpacing: 1,
              }}
            >
              {post.post_type}
            </Text>
          </View>
          
          <Text
            style={{
              fontSize: 16,
              fontWeight: 'bold',
              color: '#FFFFFF',
              marginBottom: 8,
            }}
          >
            {post.title}
          </Text>
          
          <Text
            style={{
              fontSize: 14,
              color: 'rgba(255,255,255,0.8)',
              lineHeight: 20,
            }}
          >
            {post.content}
          </Text>
        </LinearGradient>
      </Animated.View>
    </TouchableOpacity>
  );
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { data: user } = useUser();
  const [refreshing, setRefreshing] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  // Fetch user profile
  const { data: userProfile, refetch: refetchProfile } = useQuery({
    queryKey: ['userProfile'],
    queryFn: async () => {
      const response = await fetch('/api/users');
      if (!response.ok) throw new Error('Failed to fetch profile');
      return response.json();
    },
    enabled: !!user,
  });

  // Fetch posts
  const { data: posts = [], refetch: refetchPosts } = useQuery({
    queryKey: ['posts'],
    queryFn: async () => {
      const response = await fetch('/api/posts');
      if (!response.ok) throw new Error('Failed to fetch posts');
      return response.json();
    },
  });

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await Promise.all([refetchProfile(), refetchPosts()]);
    setRefreshing(false);
  };

  return (
    <LinearGradient
      colors={["#1E3A8A", "#EA580C"]}
      style={{ flex: 1 }}
    >
      <StatusBar style="light" />
      <Animated.View
        style={{
          flex: 1,
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }],
        }}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            paddingTop: insets.top + 20,
            paddingBottom: insets.bottom + 100,
            paddingHorizontal: 20,
          }}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#FFD700"
              colors={["#FFD700"]}
            />
          }
        >
          {/* Header */}
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 32 }}>
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontSize: 24,
                  fontWeight: 'bold',
                  color: '#FFFFFF',
                  marginBottom: 4,
                }}
              >
                Welcome back!
              </Text>
              <Text
                style={{
                  fontSize: 16,
                  color: 'rgba(255,255,255,0.8)',
                }}
              >
                {userProfile?.username || user?.name || 'Dropzy User'}
              </Text>
            </View>
            
            <TouchableOpacity
              onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)}
              style={{
                width: 44,
                height: 44,
                borderRadius: 22,
                backgroundColor: 'rgba(255,255,255,0.2)',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Bell size={20} color="#FFFFFF" />
            </TouchableOpacity>
          </View>

          {/* Stats Grid */}
          <View style={{ marginBottom: 32 }}>
            <Text
              style={{
                fontSize: 20,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 16,
              }}
            >
              Your Stats
            </Text>
            
            <StatsCard
              title="Total Earnings"
              value={`$${userProfile?.total_earnings || '0.00'}`}
              subtitle="Lifetime rewards earned"
              icon={DollarSign}
              color="#10B981"
              onPress={() => {}}
            />
            
            <StatsCard
              title="Referrals"
              value={userProfile?.total_referrals || '0'}
              subtitle="Friends you've referred"
              icon={Users}
              color="#8B5CF6"
              onPress={() => {}}
            />
            
            <StatsCard
              title="Referral Code"
              value={userProfile?.referral_code || 'Loading...'}
              subtitle="Share this code to earn rewards"
              icon={Share2}
              color="#F59E0B"
              onPress={() => {
                if (userProfile?.referral_code) {
                  // TODO: Share functionality
                  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                }
              }}
            />
          </View>

          {/* Latest Updates */}
          <View style={{ marginBottom: 32 }}>
            <Text
              style={{
                fontSize: 20,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 16,
              }}
            >
              Latest Updates
            </Text>
            
            {posts.length > 0 ? (
              posts.slice(0, 5).map((post) => (
                <PostCard key={post.id} post={post} />
              ))
            ) : (
              <View
                style={{
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  borderRadius: 16,
                  padding: 20,
                  alignItems: 'center',
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    color: 'rgba(255,255,255,0.7)',
                    textAlign: 'center',
                  }}
                >
                  No updates yet. Check back soon!
                </Text>
              </View>
            )}
          </View>
        </ScrollView>
      </Animated.View>
    </LinearGradient>
  );
}