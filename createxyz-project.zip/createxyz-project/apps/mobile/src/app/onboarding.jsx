import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Animated,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { useAuth } from '@/utils/auth/useAuth';

export default function OnboardingScreen() {
  const insets = useSafeAreaInsets();
  const { auth } = useAuth();
  const [username, setUsername] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const coinRotation = useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    // Entrance animation
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();

    // Continuous coin rotation
    const rotateAnimation = Animated.loop(
      Animated.timing(coinRotation, {
        toValue: 1,
        duration: 3000,
        useNativeDriver: true,
      })
    );
    rotateAnimation.start();

    return () => rotateAnimation.stop();
  }, []);

  const handleContinue = async () => {
    if (step === 1) {
      if (!username.trim()) {
        Alert.alert('Error', 'Please enter a username');
        return;
      }
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setStep(2);
      return;
    }

    if (step === 2) {
      setLoading(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

      try {
        const response = await fetch('/api/users', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            username: username.trim(),
            referred_by_code: referralCode.trim() || null,
          }),
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.error || 'Failed to create profile');
        }

        // Success animation
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        
        // Navigate to main app
        router.replace('/(tabs)');
      } catch (error) {
        console.error('Error creating profile:', error);
        Alert.alert('Error', error.message || 'Failed to create profile');
      } finally {
        setLoading(false);
      }
    }
  };

  const handleSkip = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setStep(2);
  };

  const coinRotationInterpolate = coinRotation.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  return (
    <LinearGradient
      colors={["#1E3A8A", "#EA580C"]}
      style={{ flex: 1 }}
    >
      <StatusBar style="light" />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <Animated.View
          style={{
            flex: 1,
            paddingTop: insets.top + 40,
            paddingBottom: insets.bottom + 20,
            paddingHorizontal: 24,
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          }}
        >
          {/* Header */}
          <View style={{ alignItems: 'center', marginBottom: 60 }}>
            <Animated.View
              style={{
                width: 80,
                height: 80,
                borderRadius: 40,
                backgroundColor: '#FFD700',
                justifyContent: 'center',
                alignItems: 'center',
                marginBottom: 24,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 8 },
                shadowOpacity: 0.3,
                shadowRadius: 16,
                elevation: 8,
                transform: [{ rotate: coinRotationInterpolate }],
              }}
            >
              <Text style={{ fontSize: 32, fontWeight: 'bold', color: '#1E3A8A' }}>
                D
              </Text>
            </Animated.View>
            
            <Text
              style={{
                fontSize: 28,
                fontWeight: 'bold',
                color: '#FFFFFF',
                marginBottom: 8,
                textAlign: 'center',
              }}
            >
              {step === 1 ? 'Welcome to Dropzy!' : 'Almost There!'}
            </Text>
            
            <Text
              style={{
                fontSize: 16,
                color: 'rgba(255,255,255,0.8)',
                textAlign: 'center',
                lineHeight: 24,
              }}
            >
              {step === 1 
                ? 'Choose a username to get started with your refer & earn journey'
                : 'Enter a referral code to earn bonus rewards (optional)'
              }
            </Text>
          </View>

          {/* Form */}
          <View style={{ flex: 1 }}>
            {step === 1 ? (
              <View>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: '600',
                    color: '#FFFFFF',
                    marginBottom: 12,
                  }}
                >
                  Username
                </Text>
                <View
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.15)',
                    borderRadius: 16,
                    paddingHorizontal: 20,
                    paddingVertical: 16,
                    marginBottom: 24,
                    borderWidth: 2,
                    borderColor: 'rgba(255,255,255,0.2)',
                  }}
                >
                  <TextInput
                    value={username}
                    onChangeText={setUsername}
                    placeholder="Enter your username"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                    style={{
                      fontSize: 16,
                      color: '#FFFFFF',
                      fontWeight: '500',
                    }}
                    autoCapitalize="none"
                    autoCorrect={false}
                  />
                </View>
              </View>
            ) : (
              <View>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: '600',
                    color: '#FFFFFF',
                    marginBottom: 12,
                  }}
                >
                  Referral Code (Optional)
                </Text>
                <View
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.15)',
                    borderRadius: 16,
                    paddingHorizontal: 20,
                    paddingVertical: 16,
                    marginBottom: 24,
                    borderWidth: 2,
                    borderColor: 'rgba(255,255,255,0.2)',
                  }}
                >
                  <TextInput
                    value={referralCode}
                    onChangeText={setReferralCode}
                    placeholder="Enter referral code"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                    style={{
                      fontSize: 16,
                      color: '#FFFFFF',
                      fontWeight: '500',
                    }}
                    autoCapitalize="characters"
                    autoCorrect={false}
                  />
                </View>
                
                <View
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.1)',
                    borderRadius: 12,
                    padding: 16,
                    marginBottom: 24,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      color: 'rgba(255,255,255,0.8)',
                      textAlign: 'center',
                      lineHeight: 20,
                    }}
                  >
                    💰 Get $5 bonus when you use a referral code!
                  </Text>
                </View>
              </View>
            )}
          </View>

          {/* Buttons */}
          <View style={{ gap: 16 }}>
            <TouchableOpacity
              onPress={handleContinue}
              disabled={loading}
              style={{
                backgroundColor: '#FFD700',
                borderRadius: 16,
                paddingVertical: 18,
                alignItems: 'center',
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.3,
                shadowRadius: 8,
                elevation: 4,
                opacity: loading ? 0.7 : 1,
              }}
            >
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: 'bold',
                  color: '#1E3A8A',
                }}
              >
                {loading ? 'Creating Profile...' : step === 1 ? 'Continue' : 'Start Earning!'}
              </Text>
            </TouchableOpacity>

            {step === 2 && (
              <TouchableOpacity
                onPress={() => handleContinue()}
                style={{
                  backgroundColor: 'transparent',
                  borderRadius: 16,
                  paddingVertical: 18,
                  alignItems: 'center',
                  borderWidth: 2,
                  borderColor: 'rgba(255,255,255,0.3)',
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: '600',
                    color: 'rgba(255,255,255,0.8)',
                  }}
                >
                  Skip for now
                </Text>
              </TouchableOpacity>
            )}
          </View>
        </Animated.View>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}