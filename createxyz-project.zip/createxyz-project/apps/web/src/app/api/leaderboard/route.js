import sql from "@/app/api/utils/sql";

// Get leaderboard
export async function GET(request) {
  try {
    const leaderboard = await sql`
      SELECT * FROM leaderboard
      LIMIT 50
    `;

    return Response.json(leaderboard);
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    return Response.json({ error: 'Failed to fetch leaderboard' }, { status: 500 });
  }
}