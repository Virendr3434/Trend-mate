import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Get all active posts
export async function GET(request) {
  try {
    const posts = await sql`
      SELECT * FROM posts 
      WHERE is_active = true 
      ORDER BY created_at DESC
    `;

    return Response.json(posts);
  } catch (error) {
    console.error('Error fetching posts:', error);
    return Response.json({ error: 'Failed to fetch posts' }, { status: 500 });
  }
}

// Create new post (admin only)
export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { title, content, image_url, video_url, post_type } = body;

    if (!title) {
      return Response.json({ error: 'Title is required' }, { status: 400 });
    }

    const newPost = await sql`
      INSERT INTO posts (title, content, image_url, video_url, post_type, created_by)
      VALUES (${title}, ${content || null}, ${image_url || null}, ${video_url || null}, ${post_type || 'general'}, ${session.user.id})
      RETURNING *
    `;

    return Response.json(newPost[0]);
  } catch (error) {
    console.error('Error creating post:', error);
    return Response.json({ error: 'Failed to create post' }, { status: 500 });
  }
}