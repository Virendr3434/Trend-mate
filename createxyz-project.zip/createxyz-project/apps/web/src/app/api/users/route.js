import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Generate unique referral code
function generateReferralCode() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// Create user profile
export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { username, referred_by_code } = body;

    // Check if user already exists
    const existingUser = await sql`
      SELECT id FROM users WHERE auth_user_id = ${session.user.id}
    `;

    if (existingUser.length > 0) {
      return Response.json({ error: 'User profile already exists' }, { status: 400 });
    }

    // Generate unique referral code
    let referralCode;
    let isUnique = false;
    while (!isUnique) {
      referralCode = generateReferralCode();
      const existing = await sql`
        SELECT id FROM users WHERE referral_code = ${referralCode}
      `;
      isUnique = existing.length === 0;
    }

    // Create user profile
    const newUser = await sql`
      INSERT INTO users (auth_user_id, username, referral_code, referred_by_code)
      VALUES (${session.user.id}, ${username}, ${referralCode}, ${referred_by_code || null})
      RETURNING *
    `;

    // If user was referred, create referral relationship
    if (referred_by_code) {
      const referrer = await sql`
        SELECT id FROM users WHERE referral_code = ${referred_by_code}
      `;

      if (referrer.length > 0) {
        await sql`
          INSERT INTO referrals (referrer_id, referred_id, reward_amount)
          VALUES (${referrer[0].id}, ${newUser[0].id}, 10.00)
        `;

        // Add signup bonus for new user
        await sql`
          INSERT INTO rewards (user_id, amount, reward_type, description)
          VALUES (${newUser[0].id}, 5.00, 'signup_bonus', 'Welcome bonus for joining Dropzy!')
        `;
      }
    } else {
      // Add signup bonus for new user
      await sql`
        INSERT INTO rewards (user_id, amount, reward_type, description)
        VALUES (${newUser[0].id}, 5.00, 'signup_bonus', 'Welcome bonus for joining Dropzy!')
      `;
    }

    return Response.json(newUser[0]);
  } catch (error) {
    console.error('Error creating user:', error);
    return Response.json({ error: 'Failed to create user profile' }, { status: 500 });
  }
}

// Get current user profile
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await sql`
      SELECT * FROM users WHERE auth_user_id = ${session.user.id}
    `;

    if (user.length === 0) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    return Response.json(user[0]);
  } catch (error) {
    console.error('Error fetching user:', error);
    return Response.json({ error: 'Failed to fetch user profile' }, { status: 500 });
  }
}