import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Get user rewards
export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get user profile
    const user = await sql`
      SELECT id FROM users WHERE auth_user_id = ${session.user.id}
    `;

    if (user.length === 0) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    const rewards = await sql`
      SELECT * FROM rewards 
      WHERE user_id = ${user[0].id}
      ORDER BY created_at DESC
    `;

    return Response.json(rewards);
  } catch (error) {
    console.error('Error fetching rewards:', error);
    return Response.json({ error: 'Failed to fetch rewards' }, { status: 500 });
  }
}